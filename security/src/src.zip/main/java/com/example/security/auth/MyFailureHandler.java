package com.example.security.auth;

import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

public class MyFailureHandler extends SimpleUrlAuthenticationFailureHandler {

}
