package com.example.market.service.product.impl;

import org.junit.jupiter.api.Test;

class CustomerServiceImplTest {

    @Test
    void listByCategory() {
        //Given

        //When


        //Then

    }

    @Test
    void listByName() {
    }
}