package com.example.market.service.product.impl;

import com.example.market.dto.product.ProductDto;
import com.example.market.entity.product.Category;
import com.example.market.entity.product.Product;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerServiceImplTest {

    @Test
    void listByCategory() {
        //Given

        //When


        //Then

    }

    @Test
    void listByName() {
    }
}