package com.example.market.repository.product;

import com.example.market.dto.product.ProductDto;
import com.example.market.entity.product.Category;
import com.example.market.entity.product.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategory(Category category);
    boolean existsByCategory(Category category);

    List<Product> findByName(String name);
    boolean existsByName(String name);
}
