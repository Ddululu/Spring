package com.example.market.service.user;

import com.example.market.dto.user.UserDto;

import java.util.Optional;


public interface UserService {
    void joinUser(UserDto userDto) throws IllegalAccessException;
    void updateUser(UserDto userDto);
    Boolean checkUser(UserDto userDto);
}
