package com.example.market.service.product;

import com.example.market.dto.product.ProductDto;
import com.example.market.entity.product.Category;

import java.util.List;

public abstract class CustomerService {
    public abstract List<ProductDto> listByCategory(Category category);

    public abstract List<ProductDto> listByName(String name);

}
