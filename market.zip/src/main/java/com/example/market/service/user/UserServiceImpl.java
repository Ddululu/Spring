package com.example.market.service.user;

import com.example.market.dto.user.UserDto;
import com.example.market.entity.user.User;
import com.example.market.repository.user.UserRepository;
import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository repo;
    @Autowired
    private PasswordEncoder encoder;


    @Override
    @Transactional
    public void joinUser(UserDto userDto) throws IllegalAccessException {
        User user = new User();
        if(userDto.getUsername().isEmpty()||userDto.getPassword().isEmpty()){throw new IllegalAccessException("잘못된 입력");}
            else {
                user.setUsername(userDto.getUsername());
                user.setPassword(encoder.encode(userDto.getPassword()));
            }
            repo.save(user);
    }

    @Override
    @Transactional
    public void updateUser(UserDto userDto) {
        User user = repo
                .findByUsername(userDto.getUsername())
                .orElseThrow(EntityNotFoundException::new);
       repo.save(user);
    }

    @Override
    public Boolean checkUser(UserDto userDto) {
        return repo.existsByUsername(userDto.getUsername());
    }

}
